const express = require("express");
const { ROLES } = require("../config/constants");
const {
  getStudentHome,
  getStudentUploads,
  requestUploadUrl
} = require("../controllers/studentController");
const authorizeRoles = require("../middlewares/authorizeRoles");
const verifyJWT = require("../middlewares/verifyJWT");

const router = express.Router();

router.use(verifyJWT, authorizeRoles(ROLES.STUDENT));

router.get("/home", getStudentHome);
router.get("/uploads", getStudentUploads);
router.post("/uploads/presign", requestUploadUrl);

module.exports = router;
