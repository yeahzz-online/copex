const express = require("express");
const { ROLES } = require("../config/constants");
const {
  createClass,
  createDepartment,
  createSubject,
  getAnalytics,
  getUsers
} = require("../controllers/adminController");
const authorizeRoles = require("../middlewares/authorizeRoles");
const verifyJWT = require("../middlewares/verifyJWT");

const router = express.Router();

router.use(verifyJWT, authorizeRoles(ROLES.ADMIN));

router.get("/analytics", getAnalytics);
router.get("/users", getUsers);
router.post("/departments", createDepartment);
router.post("/classes", createClass);
router.post("/subjects", createSubject);

module.exports = router;
