const express = require("express");
const { ROLES } = require("../config/constants");
const {
  getFacultyClassesList,
  getFacultyDashboard,
  getSmartboardSummary
} = require("../controllers/facultyController");
const authorizeRoles = require("../middlewares/authorizeRoles");
const verifyJWT = require("../middlewares/verifyJWT");

const router = express.Router();

router.use(verifyJWT, authorizeRoles(ROLES.FACULTY));

router.get("/dashboard", getFacultyDashboard);
router.get("/classes", getFacultyClassesList);
router.get("/smartboard/summary", getSmartboardSummary);

module.exports = router;
