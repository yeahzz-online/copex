const { query } = require("../config/db");
const { ROLES } = require("../config/constants");
const { listUsersByRole } = require("../models/userModel");
const ApiError = require("../utils/apiError");
const asyncHandler = require("../utils/asyncHandler");

const createDepartment = asyncHandler(async (req, res) => {
  const { name, code } = req.body;
  if (!name || !code) throw new ApiError(400, "name and code are required");

  const result = await query(
    `INSERT INTO departments (name, code) VALUES (?, ?)`,
    [name, code.toUpperCase()]
  );

  res.status(201).json({
    message: "Department created",
    departmentId: result.insertId
  });
});

const createClass = asyncHandler(async (req, res) => {
  const { departmentId, year, section, name } = req.body;
  if (!departmentId || !year || !section || !name) {
    throw new ApiError(400, "departmentId, year, section, and name are required");
  }

  const result = await query(
    `INSERT INTO classes (department_id, year, section, name)
     VALUES (?, ?, ?, ?)`,
    [departmentId, year, section, name]
  );

  res.status(201).json({
    message: "Class created",
    classId: result.insertId
  });
});

const createSubject = asyncHandler(async (req, res) => {
  const { classId, name, code, facultyId = null } = req.body;
  if (!classId || !name || !code) {
    throw new ApiError(400, "classId, name, and code are required");
  }

  const result = await query(
    `INSERT INTO subjects (class_id, name, code, faculty_id)
     VALUES (?, ?, ?, ?)`,
    [classId, name, code.toUpperCase(), facultyId]
  );

  res.status(201).json({
    message: "Subject created",
    subjectId: result.insertId
  });
});

const getAnalytics = asyncHandler(async (req, res) => {
  const usersCount = await query(
    `SELECT role, COUNT(*) AS total
     FROM users
     GROUP BY role`
  );
  const uploadRows = await query(`SELECT COUNT(*) AS total FROM uploads`);
  const classRows = await query(`SELECT COUNT(*) AS total FROM classes`);
  const subjectRows = await query(`SELECT COUNT(*) AS total FROM subjects`);
  const uploadCount = uploadRows[0] || { total: 0 };
  const classCount = classRows[0] || { total: 0 };
  const subjectCount = subjectRows[0] || { total: 0 };

  res.status(200).json({
    usersByRole: usersCount,
    totals: {
      uploads: Number(uploadCount?.total || 0),
      classes: Number(classCount?.total || 0),
      subjects: Number(subjectCount?.total || 0)
    }
  });
});

const getUsers = asyncHandler(async (req, res) => {
  const { role } = req.query;
  const normalizedRole = role ? String(role).toUpperCase() : null;
  if (normalizedRole && !Object.values(ROLES).includes(normalizedRole)) {
    throw new ApiError(400, "Invalid role filter");
  }

  const users = await listUsersByRole(normalizedRole);
  res.status(200).json({ users });
});

module.exports = {
  createClass,
  createDepartment,
  createSubject,
  getAnalytics,
  getUsers
};
