const bcrypt = require("bcrypt");
const { v4: uuidv4 } = require("uuid");
const { decodeToken, signAccessToken, signRefreshToken, verifyRefreshToken } = require("../config/jwt");
const {
  OTP_PURPOSES,
  ROLES,
  SMARTBOARD_SESSION_STATUS
} = require("../config/constants");
const {
  createUser,
  getUserByEmail,
  getUserById,
  markUserAsVerified,
  updatePendingUser
} = require("../models/userModel");
const {
  deleteRefreshToken,
  getRefreshToken,
  saveRefreshToken
} = require("../models/refreshTokenModel");
const {
  authorizeSession,
  consumeSession,
  createSession,
  expireSession,
  getSessionByToken
} = require("../models/smartboardSessionModel");
const { assignFacultyClasses, getFacultyClasses } = require("../models/facultyClassModel");
const { getSubjectsByFacultyId } = require("../models/subjectModel");
const { createAndSendOtp, verifyOtp } = require("../services/otpService");
const { generateQrDataUrl } = require("../services/qrService");
const ApiError = require("../utils/apiError");
const asyncHandler = require("../utils/asyncHandler");
const { hashToken } = require("../utils/crypto");
const { normalizeEmail, validateEmailByRole } = require("../utils/emailRules");

function mapOtpReasonToError(reason) {
  if (reason === "OTP_EXPIRED") return new ApiError(410, "OTP expired");
  if (reason === "OTP_INVALID") return new ApiError(400, "Invalid OTP");
  if (reason === "OTP_USED") return new ApiError(400, "OTP already used");
  return new ApiError(400, "OTP not found");
}

const register = asyncHandler(async (req, res) => {
  const {
    name,
    email,
    password,
    role,
    year = null,
    branch = null,
    section = null,
    mobile = null,
    classId = null,
    classIds = []
  } = req.body;

  const normalizedEmail = normalizeEmail(email);
  const normalizedRole = String(role || "").toUpperCase();

  if (!name || !normalizedEmail || !password || !normalizedRole) {
    throw new ApiError(400, "name, email, password, and role are required");
  }

  if (![ROLES.STUDENT, ROLES.FACULTY].includes(normalizedRole)) {
    throw new ApiError(400, "Only STUDENT or FACULTY can self-register");
  }

  if (!validateEmailByRole(normalizedEmail, normalizedRole)) {
    throw new ApiError(400, "Email does not match institutional format for role");
  }

  if (String(password).length < 8) {
    throw new ApiError(400, "Password must be at least 8 characters");
  }

  const passwordHash = await bcrypt.hash(String(password), 12);
  const existingUser = await getUserByEmail(normalizedEmail);

  let userId;
  if (existingUser?.isVerified) {
    throw new ApiError(409, "Email already registered");
  }

  if (existingUser && !existingUser.isVerified) {
    await updatePendingUser(existingUser.id, {
      name,
      passwordHash,
      role: normalizedRole,
      year,
      branch,
      section,
      mobile,
      classId
    });
    userId = existingUser.id;
  } else {
    const createResult = await createUser({
      name,
      email: normalizedEmail,
      passwordHash,
      role: normalizedRole,
      year,
      branch,
      section,
      mobile,
      classId,
      isVerified: false
    });
    userId = createResult.insertId;
  }

  if (normalizedRole === ROLES.FACULTY && Array.isArray(classIds)) {
    await assignFacultyClasses(userId, classIds);
  }

  await createAndSendOtp({
    email: normalizedEmail,
    userId,
    purpose: OTP_PURPOSES.REGISTRATION
  });

  res.status(201).json({
    message: "Registration initiated. OTP sent to email.",
    email: normalizedEmail,
    otpExpiresInMinutes: Number(process.env.OTP_EXPIRY_MINUTES || 5)
  });
});

const verifyRegistrationOtp = asyncHandler(async (req, res) => {
  const { email, otp } = req.body;
  const normalizedEmail = normalizeEmail(email);

  if (!normalizedEmail || !otp) {
    throw new ApiError(400, "email and otp are required");
  }

  const otpResult = await verifyOtp({
    email: normalizedEmail,
    otp,
    purpose: OTP_PURPOSES.REGISTRATION
  });

  if (!otpResult.valid) throw mapOtpReasonToError(otpResult.reason);

  const user = await getUserByEmail(normalizedEmail);
  if (!user) throw new ApiError(404, "User not found");

  await markUserAsVerified(user.id);

  res.status(200).json({
    message: "Account verified successfully"
  });
});

const resendRegistrationOtp = asyncHandler(async (req, res) => {
  const { email } = req.body;
  const normalizedEmail = normalizeEmail(email);
  if (!normalizedEmail) throw new ApiError(400, "email is required");

  const user = await getUserByEmail(normalizedEmail);
  if (!user) throw new ApiError(404, "User not found");
  if (user.isVerified) throw new ApiError(409, "Account is already verified");

  await createAndSendOtp({
    email: normalizedEmail,
    userId: user.id,
    purpose: OTP_PURPOSES.REGISTRATION
  });

  res.status(200).json({
    message: "OTP resent successfully"
  });
});

const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const normalizedEmail = normalizeEmail(email);

  if (!normalizedEmail || !password) {
    throw new ApiError(400, "email and password are required");
  }

  const user = await getUserByEmail(normalizedEmail);
  if (!user || !user.passwordHash) {
    throw new ApiError(401, "Invalid credentials");
  }

  if (!user.isVerified) {
    throw new ApiError(403, "Account is not verified");
  }

  if (user.role === ROLES.SMARTBOARD) {
    throw new ApiError(403, "Smartboard accounts cannot use password login");
  }

  const validPassword = await bcrypt.compare(String(password), user.passwordHash);
  if (!validPassword) throw new ApiError(401, "Invalid credentials");

  const payload = { userId: user.id, role: user.role };
  const accessToken = signAccessToken(payload);
  const refreshToken = signRefreshToken(payload);
  const decodedRefresh = decodeToken(refreshToken);

  await saveRefreshToken(
    user.id,
    hashToken(refreshToken),
    new Date(decodedRefresh.exp * 1000)
  );

  res.status(200).json({
    accessToken,
    refreshToken,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      year: user.year,
      branch: user.branch,
      section: user.section,
      classId: user.classId
    }
  });
});

const refreshAccessToken = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) throw new ApiError(400, "refreshToken is required");

  let decoded;
  try {
    decoded = verifyRefreshToken(refreshToken);
  } catch (error) {
    throw new ApiError(401, "Invalid refresh token");
  }

  const storedToken = await getRefreshToken(hashToken(refreshToken));
  if (!storedToken) throw new ApiError(401, "Refresh token revoked");

  if (new Date(storedToken.expiresAt).getTime() < Date.now()) {
    await deleteRefreshToken(hashToken(refreshToken));
    throw new ApiError(401, "Refresh token expired");
  }

  const user = await getUserById(decoded.userId);
  if (!user) throw new ApiError(401, "User not found");

  const accessToken = signAccessToken({
    userId: user.id,
    role: user.role
  });

  res.status(200).json({ accessToken });
});

const logout = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) {
    await deleteRefreshToken(hashToken(refreshToken));
  }
  res.status(204).send();
});

const createSmartboardSession = asyncHandler(async (req, res) => {
  const { smartboardName = null } = req.body;
  const sessionToken = uuidv4();
  const expiryMinutes = Number(process.env.SMARTBOARD_QR_EXPIRES_MINUTES || 2);
  const expiresAt = new Date(Date.now() + expiryMinutes * 60 * 1000);

  await createSession({
    sessionToken,
    smartboardName,
    expiresAt
  });

  const actionBase = process.env.APP_BASE_URL || process.env.CORS_ORIGINS?.split(",")[0];
  const qrActionUrl = `${String(actionBase || "http://localhost:5173").replace(/\/$/, "")}/smartboard/authorize?token=${encodeURIComponent(sessionToken)}`;
  const qrDataUrl = await generateQrDataUrl(qrActionUrl);

  res.status(201).json({
    sessionToken,
    smartboardName,
    expiresAt,
    qrActionUrl,
    qrDataUrl
  });
});

const authorizeSmartboardSessionByFaculty = asyncHandler(async (req, res) => {
  const { sessionToken } = req.body;
  if (!sessionToken) throw new ApiError(400, "sessionToken is required");

  const session = await getSessionByToken(sessionToken);
  if (!session) throw new ApiError(404, "Smartboard session not found");

  if (new Date(session.expiresAt).getTime() < Date.now()) {
    await expireSession(sessionToken);
    throw new ApiError(410, "Smartboard session expired");
  }

  if (session.status !== SMARTBOARD_SESSION_STATUS.PENDING) {
    throw new ApiError(409, "Smartboard session already processed");
  }

  await authorizeSession(sessionToken, req.user.userId);

  res.status(200).json({
    message: "Smartboard authorized successfully"
  });
});

const requestSmartboardOtp = asyncHandler(async (req, res) => {
  const { sessionToken, facultyEmail } = req.body;
  const normalizedEmail = normalizeEmail(facultyEmail);

  if (!sessionToken || !normalizedEmail) {
    throw new ApiError(400, "sessionToken and facultyEmail are required");
  }

  if (!validateEmailByRole(normalizedEmail, ROLES.FACULTY)) {
    throw new ApiError(400, "Invalid faculty email format");
  }

  const faculty = await getUserByEmail(normalizedEmail);
  if (!faculty || faculty.role !== ROLES.FACULTY || !faculty.isVerified) {
    throw new ApiError(404, "Faculty account not found or not verified");
  }

  const session = await getSessionByToken(sessionToken);
  if (!session) throw new ApiError(404, "Smartboard session not found");

  if (new Date(session.expiresAt).getTime() < Date.now()) {
    await expireSession(sessionToken);
    throw new ApiError(410, "Smartboard session expired");
  }

  if (session.status !== SMARTBOARD_SESSION_STATUS.PENDING) {
    throw new ApiError(409, "Session is not pending authorization");
  }

  await createAndSendOtp({
    email: normalizedEmail,
    userId: faculty.id,
    purpose: OTP_PURPOSES.SMARTBOARD_LOGIN,
    contextToken: sessionToken
  });

  res.status(200).json({
    message: "Smartboard OTP sent to faculty email"
  });
});

const verifySmartboardOtp = asyncHandler(async (req, res) => {
  const { sessionToken, facultyEmail, otp } = req.body;
  const normalizedEmail = normalizeEmail(facultyEmail);

  if (!sessionToken || !normalizedEmail || !otp) {
    throw new ApiError(400, "sessionToken, facultyEmail, and otp are required");
  }

  const session = await getSessionByToken(sessionToken);
  if (!session) throw new ApiError(404, "Smartboard session not found");

  if (new Date(session.expiresAt).getTime() < Date.now()) {
    await expireSession(sessionToken);
    throw new ApiError(410, "Smartboard session expired");
  }

  if (session.status !== SMARTBOARD_SESSION_STATUS.PENDING) {
    throw new ApiError(409, "Session already processed");
  }

  const otpResult = await verifyOtp({
    email: normalizedEmail,
    otp,
    purpose: OTP_PURPOSES.SMARTBOARD_LOGIN,
    contextToken: sessionToken
  });
  if (!otpResult.valid) throw mapOtpReasonToError(otpResult.reason);

  const faculty = await getUserByEmail(normalizedEmail);
  if (!faculty || faculty.role !== ROLES.FACULTY) {
    throw new ApiError(404, "Faculty account not found");
  }

  await authorizeSession(sessionToken, faculty.id);
  res.status(200).json({
    message: "Smartboard authorized through OTP"
  });
});

const exchangeSmartboardSession = asyncHandler(async (req, res) => {
  const { sessionToken } = req.body;
  if (!sessionToken) throw new ApiError(400, "sessionToken is required");

  const session = await getSessionByToken(sessionToken);
  if (!session) throw new ApiError(404, "Smartboard session not found");

  if (new Date(session.expiresAt).getTime() < Date.now()) {
    await expireSession(sessionToken);
    throw new ApiError(410, "Smartboard session expired");
  }

  if (session.status === SMARTBOARD_SESSION_STATUS.PENDING) {
    return res.status(200).json({ status: SMARTBOARD_SESSION_STATUS.PENDING });
  }

  if (session.status !== SMARTBOARD_SESSION_STATUS.AUTHORIZED) {
    throw new ApiError(401, "Session authorization failed");
  }

  const faculty = await getUserById(session.authorizedBy);
  if (!faculty) throw new ApiError(401, "Faculty authorization is invalid");

  const classes = await getFacultyClasses(faculty.id);
  const subjects = await getSubjectsByFacultyId(faculty.id);

  const accessToken = signAccessToken({
    userId: `smartboard:${session.id}`,
    role: ROLES.SMARTBOARD
  });

  await consumeSession(sessionToken);

  return res.status(200).json({
    status: SMARTBOARD_SESSION_STATUS.AUTHORIZED,
    accessToken,
    faculty: {
      id: faculty.id,
      name: faculty.name,
      email: faculty.email
    },
    classes,
    subjects
  });
});

module.exports = {
  authorizeSmartboardSessionByFaculty,
  createSmartboardSession,
  exchangeSmartboardSession,
  login,
  logout,
  refreshAccessToken,
  register,
  requestSmartboardOtp,
  resendRegistrationOtp,
  verifyRegistrationOtp,
  verifySmartboardOtp
};
