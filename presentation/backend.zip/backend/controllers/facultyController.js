const { query } = require("../config/db");
const { getFacultyClasses } = require("../models/facultyClassModel");
const { getSubjectsByFacultyId } = require("../models/subjectModel");
const asyncHandler = require("../utils/asyncHandler");

function buildInClause(ids) {
  return {
    clause: ids.map(() => "?").join(", "),
    params: ids
  };
}

const getFacultyDashboard = asyncHandler(async (req, res) => {
  const facultyId = req.user.userId;
  const classes = await getFacultyClasses(facultyId);
  const subjects = await getSubjectsByFacultyId(facultyId);
  const classIds = classes.map((item) => item.id);

  let uploadedCount = 0;
  if (classIds.length > 0) {
    const { clause, params } = buildInClause(classIds);
    const uploadedRows = await query(
      `SELECT COUNT(*) AS total
       FROM uploads u
       INNER JOIN subjects s ON u.subject_id = s.id
       WHERE s.class_id IN (${clause})`,
      params
    );
    uploadedCount = Number(uploadedRows[0]?.total || 0);
  }

  const pendingCount = Math.max(subjects.length - uploadedCount, 0);

  res.status(200).json({
    metrics: {
      assignedClasses: classes.length,
      subjectsCount: subjects.length,
      uploadedCount,
      pendingCount
    },
    classes,
    subjects
  });
});

const getFacultyClassesList = asyncHandler(async (req, res) => {
  const classes = await getFacultyClasses(req.user.userId);
  res.status(200).json({ classes });
});

const getSmartboardSummary = asyncHandler(async (req, res) => {
  const facultyId = req.user.userId;

  const rows = await query(
    `SELECT s.id AS subjectId, s.name AS subjectName, u.id AS uploadId,
            st.id AS studentId, st.email AS rollNumber, u.file_url AS fileUrl, u.created_at AS uploadedAt
     FROM subjects s
     LEFT JOIN uploads u ON u.subject_id = s.id
     LEFT JOIN users st ON st.id = u.uploaded_by
     WHERE s.faculty_id = ?
     ORDER BY s.name ASC, u.created_at DESC`,
    [facultyId]
  );

  res.status(200).json({
    smartboardData: rows
  });
});

module.exports = {
  getFacultyClassesList,
  getFacultyDashboard,
  getSmartboardSummary
};
