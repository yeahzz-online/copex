const { getUserById } = require("../models/userModel");
const { getSubjectById, getSubjectsByClassId } = require("../models/subjectModel");
const {
  countUploadsByUserId,
  createUpload,
  getUploadsByUserId
} = require("../models/uploadModel");
const { buildPublicFileUrl, createPresignedUploadUrl } = require("../services/s3Service");
const ApiError = require("../utils/apiError");
const asyncHandler = require("../utils/asyncHandler");

function buildOfficeViewerUrl(fileUrl) {
  return `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(fileUrl)}`;
}

function sanitizeFileName(fileName) {
  return String(fileName || "")
    .replace(/[^a-zA-Z0-9._-]/g, "_")
    .replace(/_+/g, "_");
}

const getStudentHome = asyncHandler(async (req, res) => {
  const user = await getUserById(req.user.userId);
  if (!user) throw new ApiError(404, "Student not found");

  const subjects = user.classId ? await getSubjectsByClassId(user.classId) : [];
  const uploadedCount = await countUploadsByUserId(user.id);
  const subjectsCount = subjects.length;
  const pendingCount = Math.max(subjectsCount - uploadedCount, 0);

  res.status(200).json({
    profile: {
      id: user.id,
      name: user.name,
      email: user.email,
      year: user.year,
      branch: user.branch,
      section: user.section
    },
    metrics: {
      subjectsCount,
      uploadedCount,
      pendingCount
    },
    subjects
  });
});

const getStudentUploads = asyncHandler(async (req, res) => {
  const uploads = await getUploadsByUserId(req.user.userId);
  res.status(200).json({
    uploads: uploads.map((item) => ({
      ...item,
      officeViewerUrl: buildOfficeViewerUrl(item.fileUrl)
    }))
  });
});

const requestUploadUrl = asyncHandler(async (req, res) => {
  const { subjectId, fileName, fileType = "application/vnd.ms-powerpoint" } = req.body;
  if (!subjectId || !fileName) {
    throw new ApiError(400, "subjectId and fileName are required");
  }

  const user = await getUserById(req.user.userId);
  if (!user) throw new ApiError(404, "Student not found");

  const subject = await getSubjectById(subjectId);
  if (!subject) throw new ApiError(404, "Subject not found");
  if (user.classId !== subject.classId) {
    throw new ApiError(403, "You can upload only for your class subjects");
  }

  const safeName = sanitizeFileName(fileName);
  const key = `${user.year || "year-unknown"}/${(user.branch || "branch-unknown").toLowerCase()}/${(user.section || "section-unknown").toLowerCase()}/${(subject.code || subject.id).toString().toLowerCase()}/${Date.now()}-${safeName}`;
  const uploadUrl = await createPresignedUploadUrl({
    key,
    contentType: fileType
  });
  const fileUrl = buildPublicFileUrl(key);

  const result = await createUpload({
    uploadedBy: user.id,
    subjectId,
    s3Key: key,
    fileUrl,
    status: "UPLOADED"
  });

  res.status(201).json({
    message: "Upload URL generated",
    uploadId: result.insertId,
    uploadUrl,
    fileUrl,
    officeViewerUrl: buildOfficeViewerUrl(fileUrl)
  });
});

module.exports = {
  getStudentHome,
  getStudentUploads,
  requestUploadUrl
};
