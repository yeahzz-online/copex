const bcrypt = require("bcrypt");
const { OTP_PURPOSES } = require("../config/constants");
const {
  createOtp,
  getLatestActiveOtp,
  markOtpUsed,
  revokeActiveOtps
} = require("../models/otpModel");
const { sendMail } = require("./mailerService");

function generateOtpCode() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function buildExpiryDate() {
  const expiryMinutes = Number(process.env.OTP_EXPIRY_MINUTES || 5);
  return new Date(Date.now() + expiryMinutes * 60 * 1000);
}

async function createAndSendOtp({
  email,
  userId = null,
  purpose = OTP_PURPOSES.REGISTRATION,
  contextToken = null
}) {
  const otp = generateOtpCode();
  const otpHash = await bcrypt.hash(otp, 10);
  const expiresAt = buildExpiryDate();

  await revokeActiveOtps({ email, purpose, contextToken });
  await createOtp({
    email,
    userId,
    otpHash,
    purpose,
    contextToken,
    expiresAt
  });

  const text = `Your CMR Smart Portal OTP is ${otp}. It expires in 5 minutes.`;
  const html = `
    <div style="font-family: Arial, sans-serif; line-height: 1.4;">
      <h3>CMR Smart Presentation Portal</h3>
      <p>Your OTP is:</p>
      <p style="font-size: 24px; font-weight: bold; letter-spacing: 2px;">${otp}</p>
      <p>This OTP expires in 5 minutes.</p>
    </div>
  `;

  await sendMail({
    to: email,
    subject: "CMR Smart Portal OTP Verification",
    text,
    html
  });

  return { expiresAt };
}

async function verifyOtp({ email, otp, purpose, contextToken = null }) {
  const record = await getLatestActiveOtp({ email, purpose, contextToken });
  if (!record) {
    return { valid: false, reason: "OTP_NOT_FOUND" };
  }

  if (record.usedAt) {
    return { valid: false, reason: "OTP_USED" };
  }

  if (new Date(record.expiresAt).getTime() < Date.now()) {
    return { valid: false, reason: "OTP_EXPIRED" };
  }

  const isMatch = await bcrypt.compare(String(otp), record.otpHash);
  if (!isMatch) {
    return { valid: false, reason: "OTP_INVALID" };
  }

  await markOtpUsed(record.id);
  return { valid: true, userId: record.userId };
}

module.exports = {
  createAndSendOtp,
  verifyOtp
};
