const { query } = require("../config/db");

async function getSubjectById(subjectId) {
  const rows = await query(
    `SELECT id, name, code, class_id AS classId, faculty_id AS facultyId
     FROM subjects
     WHERE id = ?
     LIMIT 1`,
    [subjectId]
  );
  return rows[0] || null;
}

async function getSubjectsByClassId(classId) {
  return query(
    `SELECT id, name, code, class_id AS classId, faculty_id AS facultyId
     FROM subjects
     WHERE class_id = ?
     ORDER BY name ASC`,
    [classId]
  );
}

async function getSubjectsByFacultyId(facultyId) {
  return query(
    `SELECT s.id, s.name, s.code, s.class_id AS classId, c.name AS className
     FROM subjects s
     LEFT JOIN classes c ON s.class_id = c.id
     WHERE s.faculty_id = ?
     ORDER BY s.name ASC`,
    [facultyId]
  );
}

module.exports = {
  getSubjectById,
  getSubjectsByClassId,
  getSubjectsByFacultyId
};
