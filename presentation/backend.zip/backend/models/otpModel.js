const { query } = require("../config/db");

async function createOtp({
  email,
  userId = null,
  otpHash,
  purpose,
  contextToken = null,
  expiresAt
}) {
  return query(
    `INSERT INTO otp_codes (email, user_id, otp_hash, purpose, context_token, expires_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [email, userId, otpHash, purpose, contextToken, expiresAt]
  );
}

async function getLatestActiveOtp({ email, purpose, contextToken = null }) {
  const rows = await query(
    `SELECT id, email, user_id AS userId, otp_hash AS otpHash, purpose,
            context_token AS contextToken, expires_at AS expiresAt, used_at AS usedAt
     FROM otp_codes
     WHERE email = ?
       AND purpose = ?
       AND (? IS NULL OR context_token = ?)
       AND used_at IS NULL
     ORDER BY created_at DESC
     LIMIT 1`,
    [email, purpose, contextToken, contextToken]
  );
  return rows[0] || null;
}

async function markOtpUsed(id) {
  return query("UPDATE otp_codes SET used_at = CURRENT_TIMESTAMP WHERE id = ?", [id]);
}

async function revokeActiveOtps({ email, purpose, contextToken = null }) {
  return query(
    `UPDATE otp_codes
     SET used_at = CURRENT_TIMESTAMP
     WHERE email = ?
       AND purpose = ?
       AND (? IS NULL OR context_token = ?)
       AND used_at IS NULL`,
    [email, purpose, contextToken, contextToken]
  );
}

module.exports = {
  createOtp,
  getLatestActiveOtp,
  markOtpUsed,
  revokeActiveOtps
};
