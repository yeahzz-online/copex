const { query } = require("../config/db");

async function assignFacultyClasses(facultyId, classIds = []) {
  await query("DELETE FROM faculty_classes WHERE faculty_id = ?", [facultyId]);
  if (!Array.isArray(classIds) || classIds.length === 0) return;

  const placeholders = classIds.map(() => "(?, ?)").join(", ");
  const params = classIds.flatMap((classId) => [facultyId, classId]);
  await query(
    `INSERT INTO faculty_classes (faculty_id, class_id) VALUES ${placeholders}`,
    params
  );
}

async function getFacultyClasses(facultyId) {
  return query(
    `SELECT c.id, c.name, c.year, c.section, d.name AS department, d.code AS departmentCode
     FROM faculty_classes fc
     INNER JOIN classes c ON fc.class_id = c.id
     INNER JOIN departments d ON c.department_id = d.id
     WHERE fc.faculty_id = ?
     ORDER BY c.year ASC, c.section ASC`,
    [facultyId]
  );
}

module.exports = {
  assignFacultyClasses,
  getFacultyClasses
};
