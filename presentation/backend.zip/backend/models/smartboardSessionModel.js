const { query } = require("../config/db");
const { SMARTBOARD_SESSION_STATUS } = require("../config/constants");

async function createSession({ sessionToken, smartboardName = null, expiresAt }) {
  return query(
    `INSERT INTO smartboard_sessions (session_token, smartboard_name, status, expires_at)
     VALUES (?, ?, ?, ?)`,
    [sessionToken, smartboardName, SMARTBOARD_SESSION_STATUS.PENDING, expiresAt]
  );
}

async function getSessionByToken(sessionToken) {
  const rows = await query(
    `SELECT id, session_token AS sessionToken, smartboard_name AS smartboardName,
            authorized_by AS authorizedBy, status, expires_at AS expiresAt,
            authorized_at AS authorizedAt, created_at AS createdAt
     FROM smartboard_sessions
     WHERE session_token = ?
     LIMIT 1`,
    [sessionToken]
  );
  return rows[0] || null;
}

async function authorizeSession(sessionToken, facultyId) {
  return query(
    `UPDATE smartboard_sessions
     SET status = ?, authorized_by = ?, authorized_at = CURRENT_TIMESTAMP
     WHERE session_token = ? AND status = ?`,
    [
      SMARTBOARD_SESSION_STATUS.AUTHORIZED,
      facultyId,
      sessionToken,
      SMARTBOARD_SESSION_STATUS.PENDING
    ]
  );
}

async function expireSession(sessionToken) {
  return query(
    `UPDATE smartboard_sessions
     SET status = ?
     WHERE session_token = ?`,
    [SMARTBOARD_SESSION_STATUS.EXPIRED, sessionToken]
  );
}

async function consumeSession(sessionToken) {
  return query(
    `UPDATE smartboard_sessions
     SET status = ?
     WHERE session_token = ? AND status = ?`,
    [
      SMARTBOARD_SESSION_STATUS.EXPIRED,
      sessionToken,
      SMARTBOARD_SESSION_STATUS.AUTHORIZED
    ]
  );
}

module.exports = {
  authorizeSession,
  consumeSession,
  createSession,
  expireSession,
  getSessionByToken
};
