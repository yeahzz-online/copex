const { query } = require("../config/db");

async function createUpload({ uploadedBy, subjectId, s3Key, fileUrl, status = "UPLOADED" }) {
  return query(
    `INSERT INTO uploads (uploaded_by, subject_id, s3_key, file_url, status)
     VALUES (?, ?, ?, ?, ?)`,
    [uploadedBy, subjectId, s3Key, fileUrl, status]
  );
}

async function getUploadsByUserId(userId) {
  return query(
    `SELECT u.id, u.subject_id AS subjectId, s.name AS subjectName, s.code AS subjectCode,
            u.s3_key AS s3Key, u.file_url AS fileUrl, u.status, u.created_at AS createdAt
     FROM uploads u
     INNER JOIN subjects s ON u.subject_id = s.id
     WHERE u.uploaded_by = ?
     ORDER BY u.created_at DESC`,
    [userId]
  );
}

async function countUploadsByUserId(userId) {
  const rows = await query(
    `SELECT COUNT(*) AS total
     FROM uploads
     WHERE uploaded_by = ?`,
    [userId]
  );
  return Number(rows[0]?.total || 0);
}

module.exports = {
  countUploadsByUserId,
  createUpload,
  getUploadsByUserId
};
