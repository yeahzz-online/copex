const { query } = require("../config/db");

async function saveRefreshToken(userId, tokenHash, expiresAt) {
  return query(
    `INSERT INTO refresh_tokens (user_id, token_hash, expires_at)
     VALUES (?, ?, ?)`,
    [userId, tokenHash, expiresAt]
  );
}

async function getRefreshToken(tokenHash) {
  const rows = await query(
    `SELECT id, user_id AS userId, token_hash AS tokenHash, expires_at AS expiresAt
     FROM refresh_tokens
     WHERE token_hash = ?
     LIMIT 1`,
    [tokenHash]
  );
  return rows[0] || null;
}

async function deleteRefreshToken(tokenHash) {
  return query("DELETE FROM refresh_tokens WHERE token_hash = ?", [tokenHash]);
}

async function deleteUserRefreshTokens(userId) {
  return query("DELETE FROM refresh_tokens WHERE user_id = ?", [userId]);
}

module.exports = {
  deleteRefreshToken,
  deleteUserRefreshTokens,
  getRefreshToken,
  saveRefreshToken
};
