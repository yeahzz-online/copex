const { query } = require("../config/db");

async function createUser({
  name,
  email,
  passwordHash,
  role,
  branch = null,
  year = null,
  section = null,
  mobile = null,
  classId = null,
  isVerified = false
}) {
  return query(
    `INSERT INTO users
      (name, email, password_hash, role, branch, year, section, mobile, class_id, is_verified)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      name,
      email,
      passwordHash,
      role,
      branch,
      year,
      section,
      mobile,
      classId,
      isVerified ? 1 : 0
    ]
  );
}

async function updatePendingUser(userId, data) {
  return query(
    `UPDATE users
     SET name = ?,
         password_hash = ?,
         role = ?,
         branch = ?,
         year = ?,
         section = ?,
         mobile = ?,
         class_id = ?,
         updated_at = CURRENT_TIMESTAMP
     WHERE id = ? AND is_verified = 0`,
    [
      data.name,
      data.passwordHash,
      data.role,
      data.branch || null,
      data.year || null,
      data.section || null,
      data.mobile || null,
      data.classId || null,
      userId
    ]
  );
}

async function getUserByEmail(email) {
  const rows = await query(
    `SELECT id, name, email, password_hash AS passwordHash, role, branch, year, section, mobile,
            class_id AS classId, is_verified AS isVerified, created_at AS createdAt
     FROM users
     WHERE email = ?
     LIMIT 1`,
    [email]
  );
  return rows[0] || null;
}

async function getUserById(userId) {
  const rows = await query(
    `SELECT id, name, email, role, branch, year, section, mobile,
            class_id AS classId, is_verified AS isVerified, created_at AS createdAt
     FROM users
     WHERE id = ?
     LIMIT 1`,
    [userId]
  );
  return rows[0] || null;
}

async function markUserAsVerified(userId) {
  return query(
    `UPDATE users
     SET is_verified = 1, updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`,
    [userId]
  );
}

async function listUsersByRole(role) {
  const params = [];
  let sql = `SELECT id, name, email, role, branch, year, section, mobile, is_verified AS isVerified, created_at AS createdAt
             FROM users`;
  if (role) {
    sql += " WHERE role = ?";
    params.push(role);
  }
  sql += " ORDER BY created_at DESC";
  return query(sql, params);
}

module.exports = {
  createUser,
  getUserByEmail,
  getUserById,
  listUsersByRole,
  markUserAsVerified,
  updatePendingUser
};
