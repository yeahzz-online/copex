import { Outlet } from "react-router-dom";
import BottomNav from "../components/BottomNav";
import SidebarNav from "../components/SidebarNav";
import TopBar from "../components/TopBar";
import useAuth from "../hooks/useAuth";
import { navByRole } from "../routes/navConfig";

export default function PortalLayout() {
  const { role } = useAuth();
  const navItems = navByRole[role] || [];

  if (role === "SMARTBOARD") {
    return (
      <div className="min-h-screen p-4 md:p-6">
        <main className="content-fade-in h-[calc(100vh-2rem)]">
          <Outlet />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen lg:flex">
      <SidebarNav items={navItems} role={role} />
      <div className="flex-1 p-4 pb-24 lg:p-6 lg:pl-0">
        <TopBar />
        <main className="content-fade-in">
          <Outlet />
        </main>
      </div>
      <BottomNav items={navItems} />
    </div>
  );
}
