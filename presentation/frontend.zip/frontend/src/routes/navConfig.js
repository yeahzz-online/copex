export const navByRole = {
  STUDENT: [
    { label: "Home", href: "/student/home" },
    { label: "Subjects", href: "/student/subjects" },
    { label: "Upload", href: "/student/upload" },
    { label: "Profile", href: "/student/profile" }
  ],
  FACULTY: [
    { label: "Dashboard", href: "/faculty/dashboard" },
    { label: "Classes", href: "/faculty/classes" },
    { label: "Smartboard", href: "/faculty/smartboard" },
    { label: "Profile", href: "/faculty/profile" }
  ],
  ADMIN: [
    { label: "Dashboard", href: "/admin/dashboard" },
    { label: "Departments", href: "/admin/departments" },
    { label: "Classes", href: "/admin/classes" },
    { label: "Users", href: "/admin/users" },
    { label: "Analytics", href: "/admin/analytics" },
    { label: "Settings", href: "/admin/settings" }
  ],
  SMARTBOARD: [{ label: "Presentation", href: "/smartboard/view" }]
};
