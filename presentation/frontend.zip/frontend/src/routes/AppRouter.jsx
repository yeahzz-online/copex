import { Navigate, Route, Routes } from "react-router-dom";
import PortalLayout from "../layouts/PortalLayout";
import AdminAnalyticsPage from "../pages/admin/AdminAnalyticsPage";
import AdminClassesPage from "../pages/admin/AdminClassesPage";
import AdminDashboardPage from "../pages/admin/AdminDashboardPage";
import AdminDepartmentsPage from "../pages/admin/AdminDepartmentsPage";
import AdminSettingsPage from "../pages/admin/AdminSettingsPage";
import AdminUsersPage from "../pages/admin/AdminUsersPage";
import FacultyClassesPage from "../pages/faculty/FacultyClassesPage";
import FacultyDashboardPage from "../pages/faculty/FacultyDashboardPage";
import FacultySmartboardPage from "../pages/faculty/FacultySmartboardPage";
import LoginPage from "../pages/LoginPage";
import NotFoundPage from "../pages/NotFoundPage";
import ProfilePage from "../pages/ProfilePage";
import RegisterPage from "../pages/RegisterPage";
import SmartboardConnectPage from "../pages/SmartboardConnectPage";
import SmartboardViewPage from "../pages/SmartboardViewPage";
import StudentHomePage from "../pages/student/StudentHomePage";
import StudentSubjectsPage from "../pages/student/StudentSubjectsPage";
import StudentUploadPage from "../pages/student/StudentUploadPage";
import UnauthorizedPage from "../pages/UnauthorizedPage";
import VerifyOtpPage from "../pages/VerifyOtpPage";
import useAuth from "../hooks/useAuth";
import ProtectedRoute from "./ProtectedRoute";

function RoleLanding() {
  const { role } = useAuth();
  if (role === "STUDENT") return <Navigate to="/student/home" replace />;
  if (role === "FACULTY") return <Navigate to="/faculty/dashboard" replace />;
  if (role === "ADMIN") return <Navigate to="/admin/dashboard" replace />;
  if (role === "SMARTBOARD") return <Navigate to="/smartboard/view" replace />;
  return <Navigate to="/login" replace />;
}

export default function AppRouter() {
  return (
    <Routes>
      <Route path="/" element={<RoleLanding />} />

      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/verify-otp" element={<VerifyOtpPage />} />
      <Route path="/unauthorized" element={<UnauthorizedPage />} />
      <Route path="/smartboard/connect" element={<SmartboardConnectPage />} />

      <Route
        element={<ProtectedRoute allowedRoles={["STUDENT", "FACULTY", "ADMIN", "SMARTBOARD"]} />}
      >
        <Route element={<PortalLayout />}>
          <Route element={<ProtectedRoute allowedRoles={["STUDENT"]} />}>
            <Route path="/student/home" element={<StudentHomePage />} />
            <Route path="/student/subjects" element={<StudentSubjectsPage />} />
            <Route path="/student/upload" element={<StudentUploadPage />} />
            <Route path="/student/profile" element={<ProfilePage />} />
          </Route>

          <Route element={<ProtectedRoute allowedRoles={["FACULTY"]} />}>
            <Route path="/faculty/dashboard" element={<FacultyDashboardPage />} />
            <Route path="/faculty/classes" element={<FacultyClassesPage />} />
            <Route path="/faculty/smartboard" element={<FacultySmartboardPage />} />
            <Route path="/faculty/profile" element={<ProfilePage />} />
          </Route>

          <Route element={<ProtectedRoute allowedRoles={["ADMIN"]} />}>
            <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
            <Route path="/admin/departments" element={<AdminDepartmentsPage />} />
            <Route path="/admin/classes" element={<AdminClassesPage />} />
            <Route path="/admin/users" element={<AdminUsersPage />} />
            <Route path="/admin/analytics" element={<AdminAnalyticsPage />} />
            <Route path="/admin/settings" element={<AdminSettingsPage />} />
          </Route>

          <Route element={<ProtectedRoute allowedRoles={["SMARTBOARD"]} />}>
            <Route path="/smartboard/view" element={<SmartboardViewPage />} />
          </Route>
        </Route>
      </Route>

      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}
