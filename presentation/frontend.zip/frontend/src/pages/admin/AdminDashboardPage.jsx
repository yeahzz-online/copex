import GlassCard from "../../components/GlassCard";

export default function AdminDashboardPage() {
  return (
    <GlassCard>
      <h3 className="font-display text-lg text-white">Admin Dashboard</h3>
      <p className="mt-2 text-sm text-soft">
        Manage departments, classes, faculty, students, smartboards, and system controls.
      </p>
    </GlassCard>
  );
}
