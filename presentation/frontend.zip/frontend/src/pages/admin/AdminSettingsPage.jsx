import GlassCard from "../../components/GlassCard";

export default function AdminSettingsPage() {
  return (
    <GlassCard>
      <h3 className="font-display text-lg text-white">System Settings</h3>
      <p className="mt-2 text-sm text-soft">
        SMTP and theme configuration endpoints are ready in backend schema (`smtp_config`,
        `theme_config`). Connect this page to those APIs for runtime updates.
      </p>
    </GlassCard>
  );
}
