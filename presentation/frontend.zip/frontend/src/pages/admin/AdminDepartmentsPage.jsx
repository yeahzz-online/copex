import { useState } from "react";
import GlassCard from "../../components/GlassCard";
import api from "../../services/api";

export default function AdminDepartmentsPage() {
  const [form, setForm] = useState({ name: "", code: "" });
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();
    setMessage("");
    setError("");
    try {
      await api.post("/admin/departments", form);
      setMessage("Department created successfully");
      setForm({ name: "", code: "" });
    } catch (requestError) {
      setError(requestError?.response?.data?.message || "Failed to create department");
    }
  };

  return (
    <GlassCard>
      <h3 className="font-display text-lg text-white">Departments</h3>
      <form className="mt-4 grid gap-3 md:grid-cols-2" onSubmit={handleSubmit}>
        <input
          className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none focus:border-brand-300"
          placeholder="Department name"
          value={form.name}
          onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))}
          required
        />
        <input
          className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none focus:border-brand-300"
          placeholder="Code"
          value={form.code}
          onChange={(event) => setForm((prev) => ({ ...prev, code: event.target.value }))}
          required
        />
        <button
          className="rounded-xl bg-gradient-to-r from-violetBrand-500 to-brand-500 px-4 py-3 text-sm font-semibold text-white md:col-span-2"
          type="submit"
        >
          Create Department
        </button>
      </form>
      {message ? <p className="mt-4 text-sm text-emerald-300">{message}</p> : null}
      {error ? <p className="mt-4 text-sm text-red-300">{error}</p> : null}
    </GlassCard>
  );
}
