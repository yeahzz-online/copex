import { useState } from "react";
import GlassCard from "../../components/GlassCard";
import api from "../../services/api";

export default function AdminClassesPage() {
  const [form, setForm] = useState({
    departmentId: "",
    name: "",
    year: "",
    section: ""
  });
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setMessage("");
    try {
      await api.post("/admin/classes", {
        departmentId: Number(form.departmentId),
        name: form.name,
        year: Number(form.year),
        section: form.section
      });
      setMessage("Class created successfully");
      setForm({ departmentId: "", name: "", year: "", section: "" });
    } catch (requestError) {
      setError(requestError?.response?.data?.message || "Failed to create class");
    }
  };

  return (
    <GlassCard>
      <h3 className="font-display text-lg text-white">Classes</h3>
      <form className="mt-4 grid gap-3 md:grid-cols-2" onSubmit={handleSubmit}>
        <input
          className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none focus:border-brand-300"
          placeholder="Department ID"
          value={form.departmentId}
          onChange={(event) => setForm((prev) => ({ ...prev, departmentId: event.target.value }))}
          required
        />
        <input
          className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none focus:border-brand-300"
          placeholder="Class name"
          value={form.name}
          onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))}
          required
        />
        <input
          className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none focus:border-brand-300"
          placeholder="Year"
          value={form.year}
          onChange={(event) => setForm((prev) => ({ ...prev, year: event.target.value }))}
          required
        />
        <input
          className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none focus:border-brand-300"
          placeholder="Section"
          value={form.section}
          onChange={(event) => setForm((prev) => ({ ...prev, section: event.target.value }))}
          required
        />
        <button
          className="rounded-xl bg-gradient-to-r from-violetBrand-500 to-brand-500 px-4 py-3 text-sm font-semibold text-white md:col-span-2"
          type="submit"
        >
          Create Class
        </button>
      </form>
      {message ? <p className="mt-4 text-sm text-emerald-300">{message}</p> : null}
      {error ? <p className="mt-4 text-sm text-red-300">{error}</p> : null}
    </GlassCard>
  );
}
