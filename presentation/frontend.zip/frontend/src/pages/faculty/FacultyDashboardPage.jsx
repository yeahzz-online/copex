import { useEffect, useState } from "react";
import GlassCard from "../../components/GlassCard";
import api from "../../services/api";

function Metric({ label, value }) {
  return (
    <GlassCard className="rounded-2xl p-4">
      <p className="text-xs uppercase tracking-[0.18em] text-soft">{label}</p>
      <h3 className="mt-2 font-display text-3xl text-white">{value}</h3>
    </GlassCard>
  );
}

export default function FacultyDashboardPage() {
  const [state, setState] = useState({
    loading: true,
    data: null,
    error: ""
  });

  useEffect(() => {
    async function loadData() {
      try {
        const response = await api.get("/faculty/dashboard");
        setState({ loading: false, data: response.data, error: "" });
      } catch (requestError) {
        setState({
          loading: false,
          data: null,
          error: requestError?.response?.data?.message || "Failed to load dashboard"
        });
      }
    }
    loadData();
  }, []);

  if (state.loading) return <p className="text-soft">Loading faculty dashboard...</p>;
  if (state.error) return <p className="text-red-300">{state.error}</p>;

  const metrics = state.data?.metrics || {};

  return (
    <section className="space-y-5">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
        <Metric label="Classes" value={metrics.assignedClasses || 0} />
        <Metric label="Subjects" value={metrics.subjectsCount || 0} />
        <Metric label="Uploaded" value={metrics.uploadedCount || 0} />
        <Metric label="Pending" value={metrics.pendingCount || 0} />
      </div>

      <GlassCard>
        <h3 className="font-display text-lg text-white">Assigned Classes</h3>
        <div className="mt-4 overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-soft">
              <tr>
                <th className="px-3 py-2">Class</th>
                <th className="px-3 py-2">Year</th>
                <th className="px-3 py-2">Section</th>
                <th className="px-3 py-2">Department</th>
              </tr>
            </thead>
            <tbody>
              {(state.data?.classes || []).map((item) => (
                <tr key={item.id} className="border-t border-white/10">
                  <td className="px-3 py-3">{item.name}</td>
                  <td className="px-3 py-3">{item.year}</td>
                  <td className="px-3 py-3">{item.section}</td>
                  <td className="px-3 py-3">{item.department}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </section>
  );
}
