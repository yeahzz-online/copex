import { useState } from "react";
import GlassCard from "../../components/GlassCard";
import api from "../../services/api";

export default function FacultySmartboardPage() {
  const [session, setSession] = useState(null);
  const [sessionToken, setSessionToken] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const createSession = async () => {
    setError("");
    setMessage("");
    try {
      const response = await api.post("/auth/smartboard/session", {
        smartboardName: "Classroom Smartboard"
      });
      setSession(response.data);
      setSessionToken(response.data.sessionToken);
    } catch (requestError) {
      setError(requestError?.response?.data?.message || "Failed to create smartboard session");
    }
  };

  const authorizeSession = async () => {
    setError("");
    setMessage("");
    try {
      await api.post("/auth/smartboard/authorize", { sessionToken });
      setMessage("Smartboard session authorized successfully.");
    } catch (requestError) {
      setError(requestError?.response?.data?.message || "Failed to authorize smartboard session");
    }
  };

  return (
    <section className="space-y-5">
      <GlassCard>
        <h3 className="font-display text-lg text-white">Smartboard Login</h3>
        <p className="mt-1 text-sm text-soft">
          Generate QR and authorize board login for assigned classes.
        </p>
        <button
          type="button"
          onClick={createSession}
          className="mt-4 rounded-xl bg-gradient-to-r from-violetBrand-500 to-brand-500 px-4 py-3 text-sm font-semibold text-white transition hover:brightness-110"
        >
          Generate Smartboard QR
        </button>
      </GlassCard>

      {session ? (
        <GlassCard>
          <h4 className="font-display text-base text-white">Generated Session</h4>
          <p className="mt-2 break-all text-xs text-soft">{session.sessionToken}</p>
          <img
            src={session.qrDataUrl}
            alt="Smartboard QR"
            className="mt-4 w-full max-w-xs rounded-2xl border border-white/20"
          />
          <button
            type="button"
            onClick={authorizeSession}
            className="mt-4 rounded-xl bg-white/15 px-4 py-2 text-sm text-white transition hover:bg-white/25"
          >
            Authorize This Session
          </button>
        </GlassCard>
      ) : null}

      {message ? <p className="text-emerald-300">{message}</p> : null}
      {error ? <p className="text-red-300">{error}</p> : null}
    </section>
  );
}
