import GlassCard from "../components/GlassCard";
import useAuth from "../hooks/useAuth";

export default function ProfilePage() {
  const { user } = useAuth();

  return (
    <GlassCard>
      <h3 className="font-display text-lg text-white">Profile</h3>
      <div className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
        <p>
          <span className="text-soft">Name:</span> {user?.name}
        </p>
        <p>
          <span className="text-soft">Email:</span> {user?.email}
        </p>
        <p>
          <span className="text-soft">Role:</span> {user?.role}
        </p>
        <p>
          <span className="text-soft">Branch:</span> {user?.branch || "-"}
        </p>
        <p>
          <span className="text-soft">Year:</span> {user?.year || "-"}
        </p>
        <p>
          <span className="text-soft">Section:</span> {user?.section || "-"}
        </p>
      </div>
    </GlassCard>
  );
}
