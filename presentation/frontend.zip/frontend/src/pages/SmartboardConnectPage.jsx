import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import GlassCard from "../components/GlassCard";
import api from "../services/api";
import { setAuthSession } from "../services/tokenStorage";

export default function SmartboardConnectPage() {
  const navigate = useNavigate();
  const [session, setSession] = useState(null);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("Not connected");

  useEffect(() => {
    if (!session?.sessionToken) return undefined;

    const interval = setInterval(async () => {
      try {
        const response = await api.post("/auth/smartboard/exchange", {
          sessionToken: session.sessionToken
        });

        if (response.data.status === "AUTHORIZED") {
          setAuthSession({
            accessToken: response.data.accessToken,
            user: {
              id: `smartboard-${Date.now()}`,
              name: session.smartboardName || "Smartboard",
              email: response.data.faculty?.email || "",
              role: "SMARTBOARD"
            }
          });
          navigate("/smartboard/view", { replace: true });
        } else {
          setStatus("Waiting for faculty authorization...");
        }
      } catch (requestError) {
        setError(requestError?.response?.data?.message || "Session polling failed");
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [navigate, session]);

  const startSession = async () => {
    setError("");
    setStatus("Creating smartboard session...");
    try {
      const response = await api.post("/auth/smartboard/session", {
        smartboardName: "CMR Smartboard Display"
      });
      setSession(response.data);
      setStatus("Scan this QR with faculty account to authorize.");
    } catch (requestError) {
      setError(requestError?.response?.data?.message || "Failed to start smartboard session");
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-8">
      <GlassCard className="w-full max-w-xl text-center">
        <h1 className="font-display text-2xl text-white">Smartboard Login</h1>
        <p className="mt-2 text-sm text-soft">{status}</p>
        <button
          type="button"
          onClick={startSession}
          className="mt-5 rounded-xl bg-gradient-to-r from-violetBrand-500 to-brand-500 px-5 py-3 text-sm font-semibold text-white"
        >
          Start QR Session
        </button>

        {session ? (
          <div className="mt-6 flex flex-col items-center gap-3">
            <img
              src={session.qrDataUrl}
              alt="Smartboard authorization QR"
              className="w-full max-w-xs rounded-2xl border border-white/15"
            />
            <p className="text-xs text-soft">Session token: {session.sessionToken}</p>
          </div>
        ) : null}

        {error ? <p className="mt-4 text-sm text-red-300">{error}</p> : null}
      </GlassCard>
    </div>
  );
}
