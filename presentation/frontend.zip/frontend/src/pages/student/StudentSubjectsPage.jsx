import { useEffect, useState } from "react";
import GlassCard from "../../components/GlassCard";
import api from "../../services/api";

export default function StudentSubjectsPage() {
  const [uploads, setUploads] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadUploads() {
      try {
        const response = await api.get("/student/uploads");
        setUploads(response.data.uploads || []);
      } catch (requestError) {
        setError(requestError?.response?.data?.message || "Failed to load uploads");
      }
    }
    loadUploads();
  }, []);

  return (
    <GlassCard>
      <h3 className="font-display text-lg text-white">Uploaded PPTs</h3>
      {error ? <p className="mt-3 text-red-300">{error}</p> : null}
      <div className="mt-4 space-y-3">
        {uploads.map((item) => (
          <div
            key={item.id}
            className="rounded-xl border border-white/10 bg-white/5 p-4 text-sm text-slate-100"
          >
            <p className="font-semibold">{item.subjectName}</p>
            <p className="text-xs text-soft">{item.fileUrl}</p>
            <div className="mt-2 flex flex-wrap gap-3 text-xs">
              <a className="text-brand-300 hover:text-brand-100" href={item.fileUrl} target="_blank" rel="noreferrer">
                Download
              </a>
              <a
                className="text-violetBrand-300 hover:text-violetBrand-500"
                href={item.officeViewerUrl}
                target="_blank"
                rel="noreferrer"
              >
                Open in Viewer
              </a>
            </div>
          </div>
        ))}
      </div>
    </GlassCard>
  );
}
