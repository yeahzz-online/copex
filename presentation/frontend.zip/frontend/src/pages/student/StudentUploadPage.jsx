import { useState } from "react";
import GlassCard from "../../components/GlassCard";
import api from "../../services/api";

export default function StudentUploadPage() {
  const [form, setForm] = useState({
    subjectId: "",
    fileName: "",
    fileType: "application/vnd.openxmlformats-officedocument.presentationml.presentation"
  });
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setResult(null);
    try {
      const response = await api.post("/student/uploads/presign", {
        subjectId: Number(form.subjectId),
        fileName: form.fileName,
        fileType: form.fileType
      });
      setResult(response.data);
    } catch (requestError) {
      setError(requestError?.response?.data?.message || "Failed to generate upload URL");
    }
  };

  return (
    <GlassCard>
      <h3 className="font-display text-lg text-white">Upload PPT</h3>
      <p className="mt-1 text-sm text-soft">
        Generate a secure S3 upload URL for your subject folder.
      </p>
      <form className="mt-5 grid gap-3 md:grid-cols-2" onSubmit={handleSubmit}>
        <input
          className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none placeholder:text-slate-300 focus:border-brand-300"
          placeholder="Subject ID"
          value={form.subjectId}
          onChange={(event) => setForm((prev) => ({ ...prev, subjectId: event.target.value }))}
          required
        />
        <input
          className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none placeholder:text-slate-300 focus:border-brand-300"
          placeholder="File name (example.pptx)"
          value={form.fileName}
          onChange={(event) => setForm((prev) => ({ ...prev, fileName: event.target.value }))}
          required
        />
        <input
          className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none placeholder:text-slate-300 focus:border-brand-300 md:col-span-2"
          placeholder="Content type"
          value={form.fileType}
          onChange={(event) => setForm((prev) => ({ ...prev, fileType: event.target.value }))}
        />
        <button
          className="rounded-xl bg-gradient-to-r from-violetBrand-500 to-brand-500 px-4 py-3 text-sm font-semibold text-white transition hover:brightness-110 md:col-span-2"
          type="submit"
        >
          Generate Upload URL
        </button>
      </form>

      {error ? <p className="mt-4 text-sm text-red-300">{error}</p> : null}
      {result ? (
        <div className="mt-4 rounded-xl border border-emerald-200/30 bg-emerald-200/10 p-4 text-xs">
          <p className="text-emerald-100">Upload URL generated successfully.</p>
          <p className="mt-2 break-all text-emerald-50">{result.uploadUrl}</p>
        </div>
      ) : null}
    </GlassCard>
  );
}
