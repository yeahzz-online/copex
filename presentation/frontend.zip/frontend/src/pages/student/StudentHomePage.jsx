import { useEffect, useState } from "react";
import GlassCard from "../../components/GlassCard";
import api from "../../services/api";

function MetricTile({ label, value }) {
  return (
    <GlassCard className="rounded-2xl p-4">
      <p className="text-xs uppercase tracking-[0.18em] text-soft">{label}</p>
      <h3 className="mt-2 font-display text-3xl text-white">{value}</h3>
    </GlassCard>
  );
}

export default function StudentHomePage() {
  const [state, setState] = useState({
    loading: true,
    metrics: null,
    subjects: [],
    error: ""
  });

  useEffect(() => {
    async function loadHome() {
      try {
        const response = await api.get("/student/home");
        setState({
          loading: false,
          metrics: response.data.metrics,
          subjects: response.data.subjects,
          error: ""
        });
      } catch (error) {
        setState((prev) => ({
          ...prev,
          loading: false,
          error: error?.response?.data?.message || "Failed to load student dashboard"
        }));
      }
    }

    loadHome();
  }, []);

  if (state.loading) return <p className="text-soft">Loading student home...</p>;
  if (state.error) return <p className="text-red-300">{state.error}</p>;

  return (
    <section className="space-y-5">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <MetricTile label="Subjects" value={state.metrics?.subjectsCount || 0} />
        <MetricTile label="Uploaded PPT" value={state.metrics?.uploadedCount || 0} />
        <MetricTile label="Pending PPT" value={state.metrics?.pendingCount || 0} />
      </div>

      <GlassCard>
        <h3 className="font-display text-lg text-white">Assigned Subjects</h3>
        <div className="mt-4 overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-soft">
              <tr>
                <th className="px-3 py-2">Code</th>
                <th className="px-3 py-2">Subject</th>
              </tr>
            </thead>
            <tbody>
              {state.subjects.map((subject) => (
                <tr key={subject.id} className="border-t border-white/10">
                  <td className="px-3 py-3">{subject.code}</td>
                  <td className="px-3 py-3">{subject.name}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </section>
  );
}
