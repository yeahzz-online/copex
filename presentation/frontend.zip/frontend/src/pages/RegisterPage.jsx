import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import GlassCard from "../components/GlassCard";
import useAuth from "../hooks/useAuth";

const initialForm = {
  name: "",
  email: "",
  password: "",
  role: "STUDENT",
  year: "",
  branch: "",
  section: "",
  mobile: "",
  classId: "",
  classIds: ""
};

export default function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState(initialForm);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    setMessage("");
    try {
      const payload = {
        ...form,
        year: form.year ? Number(form.year) : null,
        classId: form.classId ? Number(form.classId) : null,
        classIds: form.classIds
          ? form.classIds
              .split(",")
              .map((item) => Number(item.trim()))
              .filter(Boolean)
          : []
      };
      await register(payload);
      setMessage("Registration started. OTP sent to your email.");
      navigate("/verify-otp", { state: { email: form.email } });
    } catch (requestError) {
      setError(requestError?.response?.data?.message || "Registration failed");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-10">
      <GlassCard className="w-full max-w-xl p-6">
        <h1 className="font-display text-2xl text-white">Create Account</h1>
        <form className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2" onSubmit={handleSubmit}>
          <input
            className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none placeholder:text-slate-300 focus:border-brand-300 md:col-span-2"
            placeholder="Full name"
            value={form.name}
            onChange={(event) => handleChange("name", event.target.value)}
            required
          />
          <input
            className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none placeholder:text-slate-300 focus:border-brand-300 md:col-span-2"
            type="email"
            placeholder="Institutional email"
            value={form.email}
            onChange={(event) => handleChange("email", event.target.value)}
            required
          />
          <input
            className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none placeholder:text-slate-300 focus:border-brand-300"
            type="password"
            placeholder="Password"
            value={form.password}
            onChange={(event) => handleChange("password", event.target.value)}
            required
          />
          <select
            className="rounded-xl border border-white/20 bg-slate-900/70 px-4 py-3 text-white outline-none focus:border-brand-300"
            value={form.role}
            onChange={(event) => handleChange("role", event.target.value)}
          >
            <option value="STUDENT">Student</option>
            <option value="FACULTY">Faculty</option>
          </select>
          <input
            className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none placeholder:text-slate-300 focus:border-brand-300"
            placeholder="Year"
            value={form.year}
            onChange={(event) => handleChange("year", event.target.value)}
          />
          <input
            className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none placeholder:text-slate-300 focus:border-brand-300"
            placeholder="Branch"
            value={form.branch}
            onChange={(event) => handleChange("branch", event.target.value)}
          />
          <input
            className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none placeholder:text-slate-300 focus:border-brand-300"
            placeholder="Section"
            value={form.section}
            onChange={(event) => handleChange("section", event.target.value)}
          />
          <input
            className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none placeholder:text-slate-300 focus:border-brand-300"
            placeholder="Mobile"
            value={form.mobile}
            onChange={(event) => handleChange("mobile", event.target.value)}
          />
          <input
            className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none placeholder:text-slate-300 focus:border-brand-300"
            placeholder="Class ID (student)"
            value={form.classId}
            onChange={(event) => handleChange("classId", event.target.value)}
          />
          <input
            className="rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-white outline-none placeholder:text-slate-300 focus:border-brand-300 md:col-span-2"
            placeholder="Class IDs for faculty (comma-separated)"
            value={form.classIds}
            onChange={(event) => handleChange("classIds", event.target.value)}
          />
          {error ? <p className="text-sm text-red-300 md:col-span-2">{error}</p> : null}
          {message ? <p className="text-sm text-emerald-300 md:col-span-2">{message}</p> : null}
          <button
            className="md:col-span-2 rounded-xl bg-gradient-to-r from-violetBrand-500 to-brand-500 px-4 py-3 text-sm font-semibold text-white transition hover:brightness-110 disabled:opacity-70"
            type="submit"
            disabled={submitting}
          >
            {submitting ? "Submitting..." : "Register & Send OTP"}
          </button>
        </form>
        <p className="mt-4 text-sm text-soft">
          Already registered?{" "}
          <Link className="text-brand-300 hover:text-brand-100" to="/login">
            Sign in
          </Link>
        </p>
      </GlassCard>
    </div>
  );
}
