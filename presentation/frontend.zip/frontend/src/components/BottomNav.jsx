import { Link, useLocation } from "react-router-dom";

function isActivePath(currentPath, href) {
  return currentPath === href || currentPath.startsWith(`${href}/`);
}

export default function BottomNav({ items }) {
  const location = useLocation();

  return (
    <nav className="glass-card fixed bottom-4 left-1/2 z-50 w-[calc(100%-1.25rem)] -translate-x-1/2 rounded-2xl p-2 lg:hidden">
      <ul className="grid grid-cols-4 gap-1">
        {items.slice(0, 4).map((item) => {
          const active = isActivePath(location.pathname, item.href);
          return (
            <li key={item.href}>
              <Link
                to={item.href}
                className={`block rounded-xl px-2 py-2 text-center text-xs ${
                  active
                    ? "bg-white/20 text-white"
                    : "text-soft hover:bg-white/10 hover:text-white"
                }`}
              >
                {item.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
