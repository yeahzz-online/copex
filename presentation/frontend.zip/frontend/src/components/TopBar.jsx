import useAuth from "../hooks/useAuth";

export default function TopBar() {
  const { user, logout } = useAuth();

  return (
    <header className="glass-card mb-5 flex items-center justify-between rounded-2xl px-4 py-3">
      <div>
        <p className="text-xs uppercase tracking-[0.22em] text-soft">CMR Smart Presentation Portal</p>
        <h2 className="font-display text-lg text-white">{user?.name || "Welcome"}</h2>
      </div>
      <button
        type="button"
        onClick={logout}
        className="rounded-xl bg-white/15 px-4 py-2 text-sm text-white transition hover:bg-white/25"
      >
        Logout
      </button>
    </header>
  );
}
