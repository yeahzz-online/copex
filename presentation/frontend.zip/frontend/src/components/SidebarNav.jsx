import { Link, useLocation } from "react-router-dom";

function isActivePath(currentPath, href) {
  return currentPath === href || currentPath.startsWith(`${href}/`);
}

export default function SidebarNav({ items, role }) {
  const location = useLocation();

  return (
    <aside className="hidden w-72 shrink-0 lg:block">
      <div className="glass-card fixed m-4 h-[calc(100vh-2rem)] w-64 rounded-3xl p-5">
        <h1 className="font-display text-xl text-white">CMR Smart Portal</h1>
        <p className="mt-1 text-xs uppercase tracking-[0.22em] text-soft">{role}</p>

        <nav className="mt-8 space-y-2">
          {items.map((item) => {
            const active = isActivePath(location.pathname, item.href);
            return (
              <Link
                key={item.href}
                to={item.href}
                className={`block rounded-xl px-4 py-3 text-sm transition ${
                  active
                    ? "bg-white/20 text-white"
                    : "text-soft hover:bg-white/10 hover:text-white"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </aside>
  );
}
